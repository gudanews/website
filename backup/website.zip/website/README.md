# WordPress
Wordpress theme for GudaNews.com website
