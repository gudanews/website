<html>
<head>
    <?php wp_head();?>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php echo get_template_directory_uri();?>/favicon.ico">
</head>
